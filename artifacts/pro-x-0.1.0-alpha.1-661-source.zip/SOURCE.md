PRO-X 0.1.0-alpha.1 / 6.61: experimental; hardware NOT RUN.

This archive contains the exact inputs needed to build Installer and Fast Recovery,
including inherited libraries/March33, scripts, notices and documentation.
Unrelated IPL tools and dumping utilities are omitted. No Sony firmware or Infinity is included.
See docs/upstream.md for upstream SHA, authorship and inherited binary limitations.
Build: docker build -t pro-x-toolchain:phase1 -f scripts/Dockerfile scripts
       python scripts/build.py pro-x
Compare the resulting EBOOT files with the hashes in the binary package manifest.
Full source-scope verification uses the complete repository checkout and reference build.
