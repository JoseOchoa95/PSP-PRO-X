Common code goes here
