PRO-X 0.1.0-alpha.1 / 6.61: experimental; hardware NOT RUN.

This archive contains the exact inputs needed to build Installer and Fast Recovery,
including inherited libraries/March33, scripts, notices and documentation.
Unrelated IPL tools and dumping utilities are omitted. No Sony firmware or Infinity is included.
See docs/upstream.md for upstream SHA, authorship and inherited binary limitations.
Build: docker build -t pro-x-toolchain:phase1 -f scripts/Dockerfile scripts
       python scripts/build.py pro-x
Compare the resulting EBOOT files with the hashes in the binary package manifest.
Full source-scope verification uses the complete repository checkout and reference build.

Companion: pro-x-0.1.0-alpha.1-661-source.zip
SHA-256: dea1935aa341bc89824f2bad7a09c9be7789e6ba325692531e6e5907b7c09968
